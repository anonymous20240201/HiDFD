import torchvision.transforms as transforms
from torchvision.datasets.mnist import MNIST
from torch.utils.data import DataLoader

def get_mnist(opt):
    data_train = MNIST('/opt/data/private/data',
                       transform=transforms.Compose([
                           transforms.Resize((32, 32)),
                           transforms.ToTensor(),
                           transforms.Normalize((0.1307,), (0.3081,))
                       ]),
                       download=True)
    data_test = MNIST('/opt/data/private/data',
                      train=False,
                      transform=transforms.Compose([
                          transforms.Resize((32, 32)),
                          transforms.ToTensor(),
                          transforms.Normalize((0.1307,), (0.3081,))
                      ]),
                      download=True)

    data_train_loader = DataLoader(data_train, batch_size=opt.batch_size, shuffle=True,
                                   num_workers=opt.num_workers)
    data_test_loader = DataLoader(data_test, batch_size=100, num_workers=opt.num_workers)
    return data_train_loader, data_test_loader