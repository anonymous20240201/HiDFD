from torch.utils.data import Dataset
import os
from preprocessing.stain_normalizers import VahadaneStainNormalizer
from torchvision.datasets import ImageFolder
from glob import glob
from PIL import Image
import torchvision.transforms as transforms
import  numpy as np
class mydataset(Dataset):
    def __init__(self, folder, transform=None,use_cache=False):

        self.imgs = []
        self.use_cache = use_cache
        self.cache_data = []
        self.cache_label=[]
        for root,dirs,files in os.walk(folder):
            if len(dirs)==0 and len(files)!=0:
                imgs=glob(os.path.join(root,'*.png'))
                imgs_label = match_label(imgs)
                self.imgs+=list(zip(imgs,imgs_label))
        self.transform = transform
        super(mydataset, self).__init__()
    def __getitem__(self, idx):
        if not self.use_cache:
            fn, label = self.imgs[idx]
            img = Image.open(fn)
            # img = np.array(Image.open(fn))
            if self.transform is not None:
                img = self.transform(img)
            self.cache_data.append(img)
            self.cache_label.append(label)
        else:
            img = self.cache_data[idx]
            label = self.cache_label[idx]
        return img, label
    def set_use_cache(self,use_cache):
        if use_cache:
            x_img = tuple(self.cache_data)
            self.cache_data = torch.stack(x_img)
            lab_img = tuple(self.cache_label)
            self.cache_label = tuple(lab_img)
        else:
            self.cache_data = []
            self.cache_label= []
        self.use_cache = use_cache

    def __len__(self):
        return len(self.imgs)
