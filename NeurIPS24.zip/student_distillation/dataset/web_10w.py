import os
def count_num(dir):
    count = 0
    for sub_name in os.listdir(dir):
        sub_dir = os.path.join(dir, sub_name)
        count += len(os.listdir(sub_dir))
    print('The dir:%s have %d examples.' % (dir, count))
    return count
if __name__ == '__main__':
    web_dir = '/opt/data/private/data/web_imagenet'
    web_10w_dir = '/opt/data/private/data/web_10w'
    if not os.path.exists(web_10w_dir):
        os.makedirs(web_10w_dir)

    count_web = count_num(web_dir)
