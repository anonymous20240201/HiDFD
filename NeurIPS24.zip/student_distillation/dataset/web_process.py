import os
from PIL import Image
import cv2
import re

def to64(webv_dir='', out_dir=''):
    count = 0
    for sub_dir in os.listdir(webv_dir):
        out_dir_sub = os.path.join(out_dir, sub_dir)
        if not os.path.exists(out_dir_sub):
            os.makedirs(out_dir_sub)
        for img_name in os.listdir(os.path.join(webv_dir, sub_dir)):
            img_dir = os.path.join(webv_dir, sub_dir, img_name)
            try:
                img = cv2.imread(img_dir)
                img = cv2.resize(img, (64, 64))
                img_save_dir = os.path.join(out_dir_sub, img_name)
                cv2.imwrite(img_save_dir, img)
            except Exception as e:
                # Log the error and continue with the next image
                print(f"Error processing image {img_dir}: {str(e)}")
                continue

def to32(webv_dir='', out_dir=''):
    count = 0
    for sub_dir in os.listdir(webv_dir):
        out_dir_sub = os.path.join(out_dir, sub_dir)
        if not os.path.exists(out_dir_sub):
            os.makedirs(out_dir_sub)
        for img_name in os.listdir(os.path.join(webv_dir, sub_dir)):
            img_dir = os.path.join(webv_dir, sub_dir, img_name)
            try:
                img = cv2.imread(img_dir)
                img = cv2.resize(img, (32, 32))
                img_save_dir = os.path.join(out_dir_sub, img_name)
                cv2.imwrite(img_save_dir, img)
            except Exception as e:
                # Log the error and continue with the next image
                print(f"Error processing image {img_dir}: {str(e)}")
                continue

def count(webv_dir=''):
    count = 0
    for sub_dir in os.listdir(webv_dir):
        for img_name in os.listdir(os.path.join(webv_dir, sub_dir)):
            count = count + 1
    print(count)
    return count

def totogether(webv_dir='', out_dir='', total=0):
    count = 0
    if not os.path.exists(out_dir):
        os.makedirs(out_dir)
    for sub_dir in os.listdir(webv_dir):
        for img_name in os.listdir(os.path.join(webv_dir, sub_dir)):
            img_dir = os.path.join(webv_dir, sub_dir, img_name)
            img_name = (str(count).zfill(7) + '.jpg').zfill(7)
            # img_save_dir = '{}/{}.jpg '.format(out_dir, str(count + 1).zfill(7))
            img_save_dir = os.path.join(out_dir, img_name)
            print(img_save_dir)
            img = Image.open(img_dir)
            img.save(img_save_dir)
            print(f"Processing image {count}/{total}")
            count = count + 1

def test_resize(webv_dir=''):
    count = 0
    for sub_dir in os.listdir(webv_dir):
        out_dir_sub = os.path.join(out_dir, sub_dir)
        if not os.path.exists(out_dir_sub):
            os.makedirs(out_dir_sub)
        for img_name in os.listdir(os.path.join(webv_dir, sub_dir)):
            img_dir = os.path.join(webv_dir, sub_dir, img_name)
            img = cv2.imread(img_dir)
            print(img.size)
            img = cv2.resize(img, (32, 32))
            print(img.size)
            print(asda)

def gettiny_class(tiny_dir):
    tiny_class = os.listdir(tiny_dir)
    return tiny_class

def get_google_class(g_txt_dir, tiny_class):
    # 创建一个字典，其中每个键关联一个空列表
    identifier_to_content = {}
    value_list = []
    class_list = []
    query_list_number = []
    query_list_value = []
    map_dict = {}
    query_txt = '/opt/data/private/data/webvision/info/info/queries_google.txt'
    with open(query_txt, 'r', encoding='utf-8') as file:
        for line in file:
            line = line.strip()
            parts = line.split()
            query_list_number.append(parts[0])
            query_list_value.append(parts[1])

    with open(g_txt_dir, 'r', encoding='utf-8') as file:
        # 使用'with'语句可以确保在完成后正确关闭文件

        # 逐行读取文件内容
        for line in file:
            line = line.strip()
            if line[0:9] in tiny_class:
                class_list.append(line[0:9])
                value_list.append(line[11:])
    for i in range(len(class_list)):
        values = value_list[i].split(',')
        values = [item.strip("', ") for item in values]
        # print(values)
        for value in values:
            for j in range(len(query_list_value)):
                if value in query_list_value[j]:
                    map_dict[class_list[i]] = query_list_number[j]
                # else:
                #     print(value)

    # print(query_list_value)
    # print(map_dict)
    # print(len(map_dict))
    # print(class_list[2])
    # print(value_list[2])
    # print(value_list)
    # print(len(value_list))
    # print(map_dict.values())
    # print(map_dict.keys())
    return map_dict

def get_map_dict(txt_dir):
    map_dict = {}
    with open(txt_dir, 'r', encoding='utf-8') as file:
        for line in file:
            parts = line.split(' ')
            map_dict[parts[0]] = parts[1].rstrip()
    print(map_dict)
    print(len(map_dict))
    return map_dict
def move_google(webv_dir, out_dir, map_dict):

    for key, value in map_dict.items():
        out_dir_sub = os.path.join(out_dir, key)
        value = 'q' + str(value).zfill(4)
        webv_dir_sub = os.path.join(webv_dir, value)
        if not os.path.exists(out_dir_sub):
            os.makedirs(out_dir_sub)
        for img_name in os.listdir(webv_dir_sub):
            img_dir = os.path.join(webv_dir_sub, img_name)
            img_save_dir = os.path.join(out_dir_sub, img_name)
            img = Image.open(img_dir)
            try:
                img.save(img_save_dir)
            except Exception as e:
                print(e)
                continue



if __name__ == '__main__':
    webv_dir = '/opt/data/private/data/webvision/google'
    tiny_dir = '/opt/data/private/data/imagenet/train'
    g_txt_dir = '/opt/data/private/data/webvision/info/info/synsets.txt'
    # to64('/opt/data/private/data/web_tiny_imagenet', '/opt/data/private/data/web_tiny_imagenet_64')
    total = count('/opt/data/private/data/web_tiny_imagenet_64')
    # totogether(webv_dir_64, out_dir, total)
    # test_resize(webv_dir)
    tiny_class = gettiny_class(tiny_dir)
    map_dict = get_google_class(g_txt_dir, tiny_class)
    print(map_dict)
    print(len(map_dict))
    asdas
    move_google(webv_dir, '/opt/data/private/data/web_imagenet', map_dict)
    # map_dict = get_map_dict('/opt/data/private/data/other1.txt')
    # move_google(webv_dir, '/opt/data/private/data/web_tiny_imagenet', map_dict)
