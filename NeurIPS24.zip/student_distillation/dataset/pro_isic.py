import numpy as np
from sklearn.model_selection import train_test_split
import cv2
import os

def count_img_num(img_dir):
    img_num = 0
    for sub_dir in os.listdir(img_dir):
        img_num += len(os.listdir(os.path.join(img_dir, sub_dir)))
    return img_num

def resize_img(img_dir, img_save_dir, size=224):
    for sub_dir in os.listdir(img_dir):
        sub_dir_path = os.path.join(img_dir, sub_dir)
        sub_dir_save_path = os.path.join(img_save_dir, sub_dir)
        if not os.path.exists(sub_dir_save_path):
            os.makedirs(sub_dir_save_path)
        for img_name in os.listdir(sub_dir_path):
            img_path = os.path.join(sub_dir_path, img_name)
            img_path_save = os.path.join(sub_dir_save_path, img_name)
            img = cv2.imread(img_path)
            img = cv2.resize(img, (size, size))
            cv2.imwrite(img_path_save, img)
if __name__ == '__main__':
    img_dir = '/opt/data/private/data/ISIC'


    resize_img(img_dir, '/opt/data/private/data/ISIC_224', 224)
