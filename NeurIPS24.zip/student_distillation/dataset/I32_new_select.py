"""
get data loaders
"""
from __future__ import print_function

import os
import numpy as np
from torch.utils.data import DataLoader
from torch.utils.data.distributed import DistributedSampler
from torchvision import datasets
from torchvision import transforms
import torch
from collections import Counter

def get_data_folder(opt):
    """
    return the path to store the data
    """
    # data_folder = os.path.join('/home/tjl/', dataset)
    data_folder = opt.data_path

    if not os.path.isdir(data_folder):
        os.makedirs(data_folder)

    return data_folder


class ImageFolderInstance(datasets.ImageFolder):
    """: Folder datasets which returns the index of the image as well::
    """
    def __getitem__(self, index):
        """
        Args:
            index (int): Index
        Returns:
            tuple: (image, target) where target is class_index of the target class.
        """
        path, target = self.imgs[index]
        img = self.loader(path)
        if self.transform is not None:
            img = self.transform(img)
        if self.target_transform is not None:
            target = self.target_transform(target)

        return img, target, index


def get_i32_dataloader(opt):
    """
    Data Loader for imagenet
    """

    data_folder = get_data_folder(opt)


    normalize = transforms.Normalize(mean=[0.480, 0.457, 0.409],
                                     std=[0.275, 0.271, 0.281])
    train_transform = transforms.Compose([
        transforms.RandomResizedCrop(32),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        normalize,
    ])

    train_folder = data_folder

    train_set = ImageFolderInstance(train_folder, transform=train_transform)

    train_loader = DataLoader(train_set,
                              batch_size=opt.batch_size,
                              shuffle=False,
                              num_workers=opt.num_workers,
                              pin_memory=True)



    return train_loader, train_set


# def train_loader_select(teacher, data_train_loader, opt):
#     value = []
#     feat = []
#     index = 0
#     celoss = torch.nn.CrossEntropyLoss(reduction='none').cuda()
#     teacher.eval()
#     for i, (inputs, labels) in enumerate(data_train_loader):
#         inputs = inputs.cuda()
#         features, outputs = teacher(inputs, is_feat=True)
#         pred = outputs.data.max(1)[1]
#         loss = celoss(outputs, pred)
#         value.append(loss.detach().clone())
#         feat.append(features[-1].detach().clone())
#         index += inputs.shape[0]
#
#     feat = torch.cat(feat, dim=0)
#     values = torch.cat(value, dim=0)
#
#     feat = feat.cpu()
#     clf = ECOD()
#     clf.fit(feat)
#     ood_score = clf.decision_scores_
#     ood_score = torch.from_numpy(ood_score)
#     ood_index = ood_score.topk(opt.num_select, largest=False)[1]
#     positive_index = values.topk(opt.num_select, largest=False)[1]
#
#     print(ood_score[:20])
#     print(values[:20])
#     print(ood_index[:20])
#     print(positive_index[:20])
#     positive_index = positive_index.tolist()
#
#     data_folder = get_data_folder('I32')
#
#     normalize = transforms.Normalize(mean=[0.480, 0.457, 0.409],
#                                      std=[0.275, 0.271, 0.281])
#     train_transform = transforms.Compose([
#         transforms.RandomResizedCrop(32),
#         transforms.RandomHorizontalFlip(),
#         transforms.ToTensor(),
#         normalize,
#     ])
#
#     train_folder = data_folder
#
#     train_set = datasets.ImageFolder(train_folder, transform=train_transform)
#
#     data_train_select = torch.utils.data.Subset(train_set, positive_index)
#
#     trainloader_select = torch.utils.data.DataLoader(data_train_select, batch_size=opt.batch_size, shuffle=True,
#                                                      num_workers=opt.num_workers)
#
#     return trainloader_select

def train_loader_select_student(module_list, data_train_loader, opt):
    for module in module_list:
        module.eval()

    model_s = module_list[0]
    model_t = module_list[-1]
    cls_t = model_t.module.get_feat_modules()[-1] if opt.multiprocessing_distributed else \
        model_t.get_feat_modules()[-1]
    problist = []
    predlist = []
    classwise_acc = torch.zeros((opt.num_classes),).cuda()
    p_cutoff_cls = torch.zeros((opt.num_classes),).cuda()


    for i, (images, _, _) in enumerate(data_train_loader):
        images = images.cuda()
        feat_s, outputs_t = model_s(images, is_feat=True)
        with torch.no_grad():
            feat_t, logit_t = model_t(images, is_feat=True)
            feat_t = [f.detach() for f in feat_t]
        _, _, outputs_s = module_list[1](feat_s[-2], feat_t[-2], cls_t)
        outputs = outputs_s * 0.5 + outputs_t * 0.5
        pseudo_label = torch.softmax(outputs.detach(), dim=-1)
        max_probs, max_idx = torch.max(pseudo_label, dim=-1)

        problist.append(max_probs)
        predlist.append(max_idx)
    problist = torch.cat(problist, dim=0)
    predlist = torch.cat(predlist, dim=0)

    pseudo_counter = Counter(predlist.tolist())
    for i in range(opt.num_classes):
        classwise_acc[i] = pseudo_counter[i] / max(pseudo_counter.values())
        p_cutoff_cls[i] = opt.p_cutoff * (classwise_acc[i] / (2. - classwise_acc[i]))
    pos_idx = []

    for i in range(len(problist)):
        p_cutoff = p_cutoff_cls[predlist[i]]
        if problist[i] > p_cutoff:
            pos_idx.append(i)

    # print('*********************************************')
    # print(problist.mean())
    # print(problist[pos_idx].mean())
    # print('*********************************************')

    data_folder = get_data_folder(opt)
    # print(data_folder)

    normalize = transforms.Normalize(mean=[0.480, 0.457, 0.409],
                                     std=[0.275, 0.271, 0.281])
    train_transform = transforms.Compose([
        transforms.RandomResizedCrop(32),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        normalize,
    ])

    train_folder = data_folder

    train_set = ImageFolderInstance(train_folder, transform=train_transform)
    # print(len(train_set))
    import random
    # positive_index = random.sample([i for i in range(1, 1281167)], 50000)
    # print(positive_index)
    data_train_select = torch.utils.data.Subset(train_set, pos_idx)
    print(len(data_train_select))
    trainloader_select = torch.utils.data.DataLoader(data_train_select, batch_size=opt.batch_size, shuffle=True,
                                                     num_workers=opt.num_workers)

    # problist = []
    # max_list = []

    # teacher.eval()
    # for i, (inputs, labels, _) in enumerate(trainloader_select):
    #     inputs = inputs.cuda()
    #     outputs = teacher(inputs)
    #     pseudo_label = torch.softmax(outputs.detach(), dim=-1)
    #     max_probs, max_idx = torch.max(pseudo_label, dim=-1)
    #
    #     problist.append(max_probs)
    #     max_list.append(max_idx)
    #
    # problist = torch.cat(problist, dim=0)
    # print('************************')
    # print(problist.mean())
    # print('************************')

    return trainloader_select

def train_loader_select_teacher(model_t, data_train_loader, opt):

    model_t.eval()
    problist = []

    for i, (inputs, _, _) in enumerate(data_train_loader):
        inputs = inputs.cuda()
        outputs = model_t(inputs)
        pseudo_label = torch.softmax(outputs.detach(), dim=-1)
        max_probs, max_idx = torch.max(pseudo_label, dim=-1)

        problist.append(max_probs)

    problist = torch.cat(problist, dim=0)


    pos_idx = []
    for i in range(len(problist)):
        if problist[i] > opt.p_cutoff:
            pos_idx.append(i)

    # print('*********************************************')
    # print(problist.mean())
    # print(problist[pos_idx].mean())
    # print('*********************************************')
    data_folder = get_data_folder(opt)
    # print(data_folder)

    normalize = transforms.Normalize(mean=[0.480, 0.457, 0.409],
                                     std=[0.275, 0.271, 0.281])
    train_transform = transforms.Compose([
        transforms.RandomResizedCrop(32),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        normalize,
    ])

    train_folder = data_folder

    train_set = ImageFolderInstance(train_folder, transform=train_transform)
    # print(len(train_set))
    import random
    # positive_index = random.sample([i for i in range(1, 1281167)], 50000)
    # print(positive_index)
    data_train_select = torch.utils.data.Subset(train_set, pos_idx)
    print(len(data_train_select))
    trainloader_select = torch.utils.data.DataLoader(data_train_select, batch_size=opt.batch_size, shuffle=True,
                                                     num_workers=opt.num_workers)

    # problist = []
    # max_list = []

    # teacher.eval()
    # for i, (inputs, labels, _) in enumerate(trainloader_select):
    #     inputs = inputs.cuda()
    #     outputs = teacher(inputs)
    #     pseudo_label = torch.softmax(outputs.detach(), dim=-1)
    #     max_probs, max_idx = torch.max(pseudo_label, dim=-1)
    #
    #     problist.append(max_probs)
    #     max_list.append(max_idx)
    #
    # problist = torch.cat(problist, dim=0)
    # print('************************')
    # print(problist.mean())
    # print('************************')

    return trainloader_select

def train_loader_select(teacher, data_train_loader, opt):

    value = []
    index = 0
    celoss = torch.nn.CrossEntropyLoss(reduction='none').cuda()
    teacher.eval()
    for i, (inputs, labels, _) in enumerate(data_train_loader):
        inputs = inputs.cuda()
        outputs = teacher(inputs)
        pred = outputs.data.max(1)[1]
        loss = celoss(outputs, pred)
        value.append(loss.detach().clone())
        index += inputs.shape[0]

    values = torch.cat(value, dim=0)
    # print('************************')
    # print(values.mean())
    # print('************************')



    positive_index = values.topk(opt.num_select, largest=False)[1]

    positive_index = positive_index.tolist()


    data_folder = get_data_folder(opt)
    # print(data_folder)

    normalize = transforms.Normalize(mean=[0.480, 0.457, 0.409],
                                     std=[0.275, 0.271, 0.281])
    train_transform = transforms.Compose([
        transforms.RandomResizedCrop(32),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        normalize,
    ])

    train_folder = data_folder

    train_set = ImageFolderInstance(train_folder, transform=train_transform)
    print(len(train_set))
    import random
    # positive_index = random.sample([i for i in range(1, 1281167)], 50000)
    # print(positive_index)
    data_train_select = torch.utils.data.Subset(train_set, positive_index)
    print(len(data_train_select))
    trainloader_select = torch.utils.data.DataLoader(data_train_select, batch_size=opt.batch_size, shuffle=True,
                                                     num_workers=opt.num_workers)

    # value = []
    # index = 0
    # for i, (inputs, labels, _) in enumerate(trainloader_select):
    #     inputs = inputs.cuda()
    #     outputs = teacher(inputs)
    #     pred = outputs.data.max(1)[1]
    #     loss = celoss(outputs, pred)
    #     value.append(loss.detach().clone())
    #     index += inputs.shape[0]
    #
    # values = torch.cat(value, dim=0)
    # print('************************')
    # print(values.mean())
    # print('************************')

    return trainloader_select
