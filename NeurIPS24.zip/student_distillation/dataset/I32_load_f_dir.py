"""
get data loaders
"""
from __future__ import print_function

import os
import numpy as np
from torch.utils.data import DataLoader
from torch.utils.data.distributed import DistributedSampler
from torchvision import datasets
from torchvision import transforms
import torch
from collections import Counter
from models import model_dict
def get_data_folder(opt):
    """
    return the path to store the data
    """
    # data_folder = os.path.join('/home/tjl/', dataset)
    data_folder = opt.data_path

    if not os.path.isdir(data_folder):
        os.makedirs(data_folder)

    return data_folder


class ImageFolderInstance(datasets.ImageFolder):
    """: Folder datasets which returns the index of the image as well::
    """
    def __getitem__(self, index):
        """
        Args:
            index (int): Index
        Returns:
            tuple: (image, target) where target is class_index of the target class.
        """
        path, target = self.imgs[index]
        img = self.loader(path)
        if self.transform is not None:
            img = self.transform(img)
        if self.target_transform is not None:
            target = self.target_transform(target)
            path = self.target_transform(path)
        return img, target, path


def get_i32_dataloader(train_folder=None, batch_size=32, num_workers=4):
    """
    Data Loader for imagenet
    """

    # data_folder = get_data_folder(opt)


    normalize = transforms.Normalize(mean=[0.480, 0.457, 0.409],
                                     std=[0.275, 0.271, 0.281])
    train_transform = transforms.Compose([
        transforms.RandomResizedCrop(32),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        normalize,
    ])


    train_set = ImageFolderInstance(train_folder, transform=train_transform)

    train_loader = DataLoader(train_set,
                              batch_size=batch_size,
                              shuffle=True,
                              num_workers=num_workers,
                              pin_memory=True)



    return train_loader, train_set


# def train_loader_select(teacher, data_train_loader, opt):
#     value = []
#     feat = []
#     index = 0
#     celoss = torch.nn.CrossEntropyLoss(reduction='none').cuda()
#     teacher.eval()
#     for i, (inputs, labels) in enumerate(data_train_loader):
#         inputs = inputs.cuda()
#         features, outputs = teacher(inputs, is_feat=True)
#         pred = outputs.data.max(1)[1]
#         loss = celoss(outputs, pred)
#         value.append(loss.detach().clone())
#         feat.append(features[-1].detach().clone())
#         index += inputs.shape[0]
#
#     feat = torch.cat(feat, dim=0)
#     values = torch.cat(value, dim=0)
#
#     feat = feat.cpu()
#     clf = ECOD()
#     clf.fit(feat)
#     ood_score = clf.decision_scores_
#     ood_score = torch.from_numpy(ood_score)
#     ood_index = ood_score.topk(opt.num_select, largest=False)[1]
#     positive_index = values.topk(opt.num_select, largest=False)[1]
#
#     print(ood_score[:20])
#     print(values[:20])
#     print(ood_index[:20])
#     print(positive_index[:20])
#     positive_index = positive_index.tolist()
#
#     data_folder = get_data_folder('I32')
#
#     normalize = transforms.Normalize(mean=[0.480, 0.457, 0.409],
#                                      std=[0.275, 0.271, 0.281])
#     train_transform = transforms.Compose([
#         transforms.RandomResizedCrop(32),
#         transforms.RandomHorizontalFlip(),
#         transforms.ToTensor(),
#         normalize,
#     ])
#
#     train_folder = data_folder
#
#     train_set = datasets.ImageFolder(train_folder, transform=train_transform)
#
#     data_train_select = torch.utils.data.Subset(train_set, positive_index)
#
#     trainloader_select = torch.utils.data.DataLoader(data_train_select, batch_size=opt.batch_size, shuffle=True,
#                                                      num_workers=opt.num_workers)
#
#     return trainloader_select

def train_loader_select_student(student, data_train_loader, train_set, opt):

    problist = []
    predlist = []
    classwise_acc = torch.zeros((opt.num_classes),).cuda()
    p_cutoff_cls = torch.zeros((opt.num_classes),).cuda()

    student.eval()
    for i, (inputs, labels, _) in enumerate(data_train_loader):
        inputs = inputs.cuda()
        outputs = student(inputs)
        pseudo_label = torch.softmax(outputs.detach(), dim=-1)
        max_probs, max_idx = torch.max(pseudo_label, dim=-1)

        problist.append(max_probs)
        predlist.append(max_idx)
    problist = torch.cat(problist, dim=0)
    predlist = torch.cat(predlist, dim=0)

    pseudo_counter = Counter(predlist.tolist())
    for i in range(opt.num_classes):
        classwise_acc[i] = pseudo_counter[i] / max(pseudo_counter.values())
        p_cutoff_cls[i] = opt.p_cutoff * (classwise_acc[i] / (2. - classwise_acc[i]))

    pos_idx = []

    for i in range(len(problist)):
        p_cutoff = p_cutoff_cls[predlist[i]]
        if problist[i] > p_cutoff:
            pos_idx.append(i)

    data_train_select = torch.utils.data.Subset(train_set, pos_idx)
    print('Select_sampes %d' % (len(data_train_select)))
    trainloader_select = torch.utils.data.DataLoader(data_train_select, batch_size=opt.batch_size, shuffle=False,
                                                     num_workers=opt.num_workers)

    # problist = []
    # max_list = []

    # teacher.eval()
    # for i, (inputs, labels, _) in enumerate(trainloader_select):
    #     inputs = inputs.cuda()
    #     outputs = teacher(inputs)
    #     pseudo_label = torch.softmax(outputs.detach(), dim=-1)
    #     max_probs, max_idx = torch.max(pseudo_label, dim=-1)
    #
    #     problist.append(max_probs)
    #     max_list.append(max_idx)
    #
    # problist = torch.cat(problist, dim=0)
    # print('************************')
    # print(problist.mean())
    # print('************************')

    return trainloader_select

def train_loader_select_teacher(teacher, data_train_loader):

    problist = []
    predlist = []
    pathlist = []

    teacher.eval()
    for i, (inputs, labels, paths) in enumerate(data_train_loader):

        inputs = inputs.cuda()
        outputs = teacher(inputs)
        probs, preds = torch.max(outputs, dim=-1)
        problist.append(probs.detach())
        predlist.append(preds.detach())
        for path in paths:
            pathlist.append(path)


    problist = torch.cat(problist, dim=0)
    predlist = torch.cat(predlist, dim=0)

    return problist, predlist, pathlist

def train_loader_select(teacher, data_train_loader, opt):
    value = []
    index = 0
    celoss = torch.nn.CrossEntropyLoss(reduction='none').cuda()
    teacher.eval()
    for i, (inputs, labels, _) in enumerate(data_train_loader):
        inputs = inputs.cuda()
        outputs = teacher(inputs)
        pred = outputs.data.max(1)[1]
        loss = celoss(outputs, pred)
        value.append(loss.detach().clone())
        index += inputs.shape[0]

    values = torch.cat(value, dim=0)
    # print('************************')
    # print(values.mean())
    # print('************************')



    positive_index = values.topk(opt.num_select, largest=False)[1]

    positive_index = positive_index.tolist()


    data_folder = get_data_folder(opt)
    # print(data_folder)

    normalize = transforms.Normalize(mean=[0.480, 0.457, 0.409],
                                     std=[0.275, 0.271, 0.281])
    train_transform = transforms.Compose([
        transforms.RandomResizedCrop(32),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        normalize,
    ])

    train_folder = data_folder

    train_set = ImageFolderInstance(train_folder, transform=train_transform)
    print(len(train_set))
    import random
    # positive_index = random.sample([i for i in range(1, 1281167)], 50000)
    # print(positive_index)
    data_train_select = torch.utils.data.Subset(train_set, positive_index)
    print(len(data_train_select))
    trainloader_select = torch.utils.data.DataLoader(data_train_select, batch_size=opt.batch_size, shuffle=True,
                                                     num_workers=opt.num_workers)

    # value = []
    # index = 0
    # for i, (inputs, labels, _) in enumerate(trainloader_select):
    #     inputs = inputs.cuda()
    #     outputs = teacher(inputs)
    #     pred = outputs.data.max(1)[1]
    #     loss = celoss(outputs, pred)
    #     value.append(loss.detach().clone())
    #     index += inputs.shape[0]
    #
    # values = torch.cat(value, dim=0)
    # print('************************')
    # print(values.mean())
    # print('************************')

    return trainloader_select


def load_teacher(model_path, n_cls, model_t):
    print('==> loading teacher model')
    # model_t = get_teacher_name(model_path)
    model = model_dict[model_t](num_classes=n_cls)
    model.load_state_dict(torch.load(model_path, map_location=None)['model'])
    print('==> done')
    return model

def npy_loader(path):
    sample = np.load(path)
    return sample
# if __name__ == '__main__':
#     import os
#     save_dir = '/opt/data/private/data/I32_CIFAR100_5w'
#     count = 0
#     for sub_dir in os.listdir(save_dir):
#         sub_dir_path = os.path.join(save_dir, sub_dir)
#         sub_list = os.listdir(sub_dir_path)
#         print(len(sub_list))
#         count += len(sub_list)
#     print(count)
    # import shutil
    # path = npy_loader('/opt/data/private/code/SimKD-AB/dataset/path100.npy')
    # pred = npy_loader('/opt/data/private/code/SimKD-AB/dataset/pred100.npy')
    # prob = npy_loader('/opt/data/private/code/SimKD-AB/dataset/prob100.npy')
    # save_dir = '/opt/data/private/data/I32_CIFAR100_5w'
    # if not os.path.exists(save_dir):
    #     os.makedirs(save_dir)
    #
    # count_for_each_class = [0 for i in range(100)]
    #
    # sorted_indices = sorted(range(len(prob)), key=lambda x: prob[x], reverse=True)
    # sorted_path = [path[i] for i in sorted_indices]
    # sorted_pred = [pred[i] for i in sorted_indices]
    # sorted_prob = [prob[i] for i in sorted_indices]
    #
    # for i in range(len(sorted_pred)):
    #     sub_dir = os.path.join(save_dir, str(sorted_pred[i]))
    #     count_for_each_class[sorted_pred[i]] += 1
    #     if not os.path.exists(sub_dir):
    #         os.makedirs(sub_dir)
    #
    #     if count_for_each_class[sorted_pred[i]] <= 5000:
    #         shutil.copy(sorted_path[i], sub_dir)
    # count = 0
    # for c in count_for_each_class:
    #     count += c
    # print(c)

if __name__ == '__main__':
    data_dir = '/opt/data/private/data/I32'
    teacher_dir = '/opt/data/private/code/SimKD-AB/save/teachers/models/resnet34_cifar_vanilla_cinic_trial_0/resnet34_cifar_best.pth'
    data_folder, _ = get_i32_dataloader(train_folder=data_dir, batch_size=64, num_workers=4)
    teacher = load_teacher(teacher_dir, 10, 'resnet34_cifar')
    teacher = teacher.cuda()
    teacher.eval()
    problist, predlist, pathlist = train_loader_select_teacher(teacher, data_folder)

    problist_cpu = problist.cpu()
    predlist_cpu = predlist.cpu()

    problist_cpu_np = np.array(problist_cpu)
    predlist_cpu_np = np.array(predlist_cpu)
    pathlist_np = np.array(pathlist)

    np.save('prob_cinic_10.npy', problist_cpu_np)
    np.save('prob_cinic_10.npy', predlist_cpu_np)
    np.save('prob_cinic_10.npy', pathlist_np)