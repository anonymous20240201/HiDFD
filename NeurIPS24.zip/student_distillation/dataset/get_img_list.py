import os

def list_image_paths(root_dir, file_exts=['.jpg', '.jpeg', '.png']):
    image_paths = []
    for root, dirs, files in os.walk(root_dir):
        for file in files:
            _, ext = os.path.splitext(file)
            if ext.lower() in file_exts:
                image_paths.append(os.path.join(root, file))
    return image_paths

def write_paths_to_txt(image_paths, txt_file):
    with open(txt_file, 'w') as f:
        for path in image_paths:
            f.write(path + '\n')

if __name__ == "__main__":
    dataset_dir = "/opt/data/private/data/I32"
    txt_file = "/opt/data/private/data/I32.txt"

    image_paths = list_image_paths(dataset_dir)
    write_paths_to_txt(image_paths, txt_file)

    print(f"Total {len(image_paths)} image paths have been written to {txt_file}.")

