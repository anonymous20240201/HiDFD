import os
IMG_DIR = '/opt/data/common/Data_set/ILSVRC2012/imagenet/train'
count = 0
for sub_dir in os.listdir(IMG_DIR):
    for img in os.listdir(os.path.join(IMG_DIR, sub_dir)):
        count += 1
print(count)
