"""
get data loaders
"""
from __future__ import print_function

import os
import cv2
import numpy as np
from torch.utils.data import DataLoader
from torch.utils.data.distributed import DistributedSampler
from torchvision import datasets
from torchvision import transforms
import torch
from pyod.models.ecod import ECOD
import tqdm

def get_data_folder(dataset='I32'):
    """
    return the path to store the data
    """
    data_folder = os.path.join('/home/tjl/', dataset)

    if not os.path.isdir(data_folder):
        os.makedirs(data_folder)

    return data_folder


class ImageFolderInstance(datasets.ImageFolder):
    """: Folder datasets which returns the index of the image as well::
    """
    def __getitem__(self, index):
        """
        Args:
            index (int): Index
        Returns:
            tuple: (image, target) where target is class_index of the target class.
        """
        path, target = self.imgs[index]
        img = self.loader(path)
        if self.transform is not None:
            img = self.transform(img)
        if self.target_transform is not None:
            target = self.target_transform(target)

        return img, target, index


def get_i32_dataloader(batch_size=128, num_workers=8,
                            multiprocessing_distributed=False):
    """
    Data Loader for imagenet
    """

    data_folder = get_data_folder('I32')


    normalize = transforms.Normalize(mean=[0.480, 0.457, 0.409],
                                     std=[0.275, 0.271, 0.281])
    train_transform = transforms.Compose([
        transforms.RandomResizedCrop(32),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        normalize,
    ])

    train_folder = data_folder

    train_set = datasets.ImageFolder(train_folder, transform=train_transform)

    if multiprocessing_distributed:
        train_sampler = DistributedSampler(train_set)
    else:
        train_sampler = None

    train_loader = DataLoader(train_set,
                              batch_size=batch_size,
                              shuffle=(train_sampler is None),
                              num_workers=num_workers,
                              pin_memory=True,
                              sampler=train_sampler)



    return train_loader, train_sampler


# def train_loader_select(teacher, data_train_loader, opt):
#     value = []
#     feat = []
#     index = 0
#     celoss = torch.nn.CrossEntropyLoss(reduction='none').cuda()
#     teacher.eval()
#     for i, (inputs, labels) in enumerate(data_train_loader):
#         inputs = inputs.cuda()
#         features, outputs = teacher(inputs, is_feat=True)
#         pred = outputs.data.max(1)[1]
#         loss = celoss(outputs, pred)
#         value.append(loss.detach().clone())
#         feat.append(features[-1].detach().clone())
#         index += inputs.shape[0]
#
#     feat = torch.cat(feat, dim=0)
#     values = torch.cat(value, dim=0)
#
#     feat = feat.cpu()
#     clf = ECOD()
#     clf.fit(feat)
#     ood_score = clf.decision_scores_
#     ood_score = torch.from_numpy(ood_score)
#     ood_index = ood_score.topk(opt.num_select, largest=False)[1]
#     positive_index = values.topk(opt.num_select, largest=False)[1]
#
#     print(ood_score[:20])
#     print(values[:20])
#     print(ood_index[:20])
#     print(positive_index[:20])
#     positive_index = positive_index.tolist()
#
#     data_folder = get_data_folder('I32')
#
#     normalize = transforms.Normalize(mean=[0.480, 0.457, 0.409],
#                                      std=[0.275, 0.271, 0.281])
#     train_transform = transforms.Compose([
#         transforms.RandomResizedCrop(32),
#         transforms.RandomHorizontalFlip(),
#         transforms.ToTensor(),
#         normalize,
#     ])
#
#     train_folder = data_folder
#
#     train_set = datasets.ImageFolder(train_folder, transform=train_transform)
#
#     data_train_select = torch.utils.data.Subset(train_set, positive_index)
#
#     trainloader_select = torch.utils.data.DataLoader(data_train_select, batch_size=opt.batch_size, shuffle=True,
#                                                      num_workers=opt.num_workers)
#
#     return trainloader_select
#     for i, (inputs, labels) in enumerate(data_train_loader):
#         inputs = inputs.cuda()
#         features, outputs = teacher(inputs, is_feat=True)
#         pred = outputs.data.max(1)[1]
#         loss = celoss(outputs, pred)
#         value.append(loss.detach().clone())
#         temp = p_linear(features[-1]).detach()
#         feat.append(temp)
#         index += inputs.shape[0]
def train_loader_select(teacher, data_train_loader, opt):
    value = []
    feat = []
    index = 0
    from PIL import Image

    p_linear = torch.nn.Linear(512, 128).cuda()
    celoss = torch.nn.CrossEntropyLoss(reduction='none').cuda()
    teacher.eval()
    for i, (inputs, labels) in enumerate(data_train_loader):
        inputs = inputs.cuda()

        features, outputs = teacher(inputs, is_feat=True)
        temp = p_linear(features[-1]).detach()
        feat.append(temp)

    feat = torch.cat(feat, dim=0)
    feat = feat.cpu()
    clf = ECOD()
    clf.fit(feat)
    pred_out = clf.labels_
    outlier = np.where(pred_out == 1)
    inlier = np.where(pred_out == 0)
    outlier = list(outlier)
    inlier = list(inlier)
    outlier = [i for i in outlier[0]]
    inlier = [i for i in inlier[0]]
    # check = [i for i in outlier if i in inlier]
    # print(check)
    # print(len(outlier))
    # print(len(inlier))


    data_folder = get_data_folder('I32')

    normalize = transforms.Normalize(mean=[0.480, 0.457, 0.409],
                                     std=[0.275, 0.271, 0.281])
    # train_transform = transforms.Compose([
    #     transforms.RandomResizedCrop(32),
    #     transforms.RandomHorizontalFlip(),
    #     transforms.ToTensor(),
    #     normalize,
    # ])
    train_transform = transforms.Compose([
        transforms.ToTensor()])

    train_folder = data_folder

    train_set = datasets.ImageFolder(train_folder, transform=train_transform)

    data_train_select = torch.utils.data.Subset(train_set, inlier)


    trainloader_select = torch.utils.data.DataLoader(data_train_select, batch_size=opt.batch_size, shuffle=True,
                                                     num_workers=opt.num_workers)
    save_path = '/home/tjl/select_data/select_inlear'
    count = 0
    for i, (inputs, labels) in enumerate(trainloader_select):
        inputs = inputs.cuda()
        for idx, img in enumerate(inputs):
            img = np.array(img.cpu().detach())
            img = img.transpose((2, 1, 0))

            img_name = str(count) + '.JPEG'
            img_sub_dir = os.path.join(save_path, str(int(labels[idx])))
            img_dir = os.path.join(img_sub_dir, img_name)
            print(img_dir)
            # print(img_dir)
            # print(img.shape)

            cv2.imwrite(img_dir, cv2.cvtColor(img, cv2.COLOR_RGB2BGR)*255)
            count = count + 1
        # pred = outputs.data.max(1)[1]
        # loss = celoss(outputs, pred)
        # value.append(loss.detach().clone())


    for i, (inputs, labels) in enumerate(trainloader_select):
        inputs = inputs.cuda()
        outputs = teacher(inputs)
        pred = outputs.data.max(1)[1]
        loss = celoss(outputs, pred)
        value.append(loss.detach().clone())
    values = torch.cat(value, dim=0)


    positive_index = values.topk(opt.num_select, largest=False)[1]

    positive_index = positive_index.tolist()

    # train_folder = data_folder
    #
    # train_set = datasets.ImageFolder(train_folder, transform=train_transform)
    #
    data_train_select = torch.utils.data.Subset(train_set, inlier)

    trainloader_select = torch.utils.data.DataLoader(data_train_select, batch_size=opt.batch_size, shuffle=True,
                                                     num_workers=opt.num_workers)

    # f_index = [i for i in positive_index if i not in outlier]
    # ood_index = ood_index.tolist()
    # f_index = [i for i in positive_index if i in ood_index]
    # f_index = list(set(positive_index) - set(ood_index))
    # print(len(f_index))

    # return trainloader_select
