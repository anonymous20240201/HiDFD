"""
get data loaders
"""
from __future__ import print_function

import _pickle

import torch
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
from collections import Counter
from PIL import Image


def unpickle(file):
    import _pickle as cPickle
    with open(file, 'rb') as fo:
        dict = cPickle.load(fo, encoding='latin1')
    return dict


class I32_dataset(Dataset):
    def __init__(self, opt, transform, model='normal', pred=[]):

        self.transform = transform
        self.model = model
        train_folder = opt.data_path
        with open(train_folder, 'rb') as fo:
            dict = _pickle.load(fo, encoding='latin1')
            self.train_data = dict['train']['data']
            self.train_target = dict['train']['target']

        data_num = len(self.train_data)
        self.train_data = self.train_data.reshape((data_num, -1, 32, 32))
        self.train_data = self.train_data.transpose((0, 2, 3, 1))

        if self.model == 'select':
            self.train_data = self.train_data[pred]
            self.train_target = self.train_target[pred]


    def __getitem__(self, index):
        img, target = self.train_data[index], self.train_target[index]
        # img = self.train_data[index]
        img = Image.fromarray(img)
        img = self.transform(img)
        return img, target, index

    def __len__(self):
        return len(self.train_data)

def get_imagenet_dataloader(opt, model='', pred=[]):
    normalize = transforms.Normalize(mean=[0.480, 0.457, 0.409],
                                     std=[0.275, 0.271, 0.281])

    train_transform = transforms.Compose([
        transforms.RandomResizedCrop(32),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        normalize,
    ])
    npy_data = I32_dataset(opt, train_transform, model, pred)
    print(len(npy_data))
    # print(npy_data.size)
    trainloader = DataLoader(
        dataset=npy_data,
        batch_size=opt.batch_size,
        shuffle=False,
        num_workers=opt.num_workers)
    return trainloader

def get_I32_dataloader(opt, model='normal', pred=[]):
    normalize = transforms.Normalize(mean=[0.480, 0.457, 0.409],
                                     std=[0.275, 0.271, 0.281])

    train_transform = transforms.Compose([
        transforms.RandomResizedCrop(32),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        normalize,
    ])
    npy_data = I32_dataset(opt, train_transform, model, pred)
    print(len(npy_data))

    trainloader = DataLoader(
        dataset=npy_data,
        batch_size=opt.batch_size,
        shuffle=False,
        num_workers=opt.num_workers)
    return trainloader, npy_data

def train_loader_select_teacher(teacher, data_train_loader, train_set, opt):

    problist = []

    teacher.eval()
    for i, (inputs, labels, _) in enumerate(data_train_loader):
        inputs = inputs.cuda()
        outputs = teacher(inputs)
        pseudo_label = torch.softmax(outputs.detach(), dim=-1)
        max_probs, max_idx = torch.max(pseudo_label, dim=-1)

        problist.append(max_probs)

    problist = torch.cat(problist, dim=0)


    pos_idx = []
    for i in range(len(problist)):
        if problist[i] > opt.p_cutoff:
            pos_idx.append(i)

    data_train_select = torch.utils.data.Subset(train_set, pos_idx)
    print('Select_sampes %d' % (len(data_train_select)))
    trainloader_select = torch.utils.data.DataLoader(data_train_select, batch_size=opt.batch_size, shuffle=False,
                                                     num_workers=opt.num_workers)

    # problist = []
    # max_list = []

    # teacher.eval()
    # for i, (inputs, labels, _) in enumerate(trainloader_select):
    #     inputs = inputs.cuda()
    #     outputs = teacher(inputs)
    #     pseudo_label = torch.softmax(outputs.detach(), dim=-1)
    #     max_probs, max_idx = torch.max(pseudo_label, dim=-1)
    #
    #     problist.append(max_probs)
    #     max_list.append(max_idx)
    #
    # problist = torch.cat(problist, dim=0)
    # print('************************')
    # print(problist.mean())
    # print('************************')

    return trainloader_select

def train_loader_select_student(student, data_train_loader, train_set, opt):

    problist = []
    predlist = []
    classwise_acc = torch.zeros((opt.num_classes),).cuda()
    p_cutoff_cls = torch.zeros((opt.num_classes),).cuda()

    student.eval()
    for i, (inputs, labels, _) in enumerate(data_train_loader):
        inputs = inputs.cuda()
        outputs = student(inputs)
        pseudo_label = torch.softmax(outputs.detach(), dim=-1)
        max_probs, max_idx = torch.max(pseudo_label, dim=-1)

        problist.append(max_probs)
        predlist.append(max_idx)
    problist = torch.cat(problist, dim=0)
    predlist = torch.cat(predlist, dim=0)

    pseudo_counter = Counter(predlist.tolist())
    for i in range(opt.num_classes):
        classwise_acc[i] = pseudo_counter[i] / max(pseudo_counter.values())
        p_cutoff_cls[i] = opt.p_cutoff * (classwise_acc[i] / (2. - classwise_acc[i]))

    pos_idx = []

    for i in range(len(problist)):
        p_cutoff = p_cutoff_cls[predlist[i]]
        if problist[i] > p_cutoff:
            pos_idx.append(i)

    data_train_select = torch.utils.data.Subset(train_set, pos_idx)
    print('Select_sampes %d' % (len(data_train_select)))
    trainloader_select = torch.utils.data.DataLoader(data_train_select, batch_size=opt.batch_size, shuffle=False,
                                                     num_workers=opt.num_workers)

    # problist = []
    # max_list = []

    # teacher.eval()
    # for i, (inputs, labels, _) in enumerate(trainloader_select):
    #     inputs = inputs.cuda()
    #     outputs = teacher(inputs)
    #     pseudo_label = torch.softmax(outputs.detach(), dim=-1)
    #     max_probs, max_idx = torch.max(pseudo_label, dim=-1)
    #
    #     problist.append(max_probs)
    #     max_list.append(max_idx)
    #
    # problist = torch.cat(problist, dim=0)
    # print('************************')
    # print(problist.mean())
    # print('************************')

    return trainloader_select