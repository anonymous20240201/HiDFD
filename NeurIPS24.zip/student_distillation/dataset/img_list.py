import os

# 主文件夹路径
parent_folder = "/opt/data/private/data/HAM/HAM_CLS"

# 遍历主文件夹下的子文件夹
subfolders = [subfolder for subfolder in os.listdir(parent_folder) if os.path.isdir(os.path.join(parent_folder, subfolder))]

# 打开文本文件进行写入
txt_dir = os.path.join(parent_folder, "image_list.txt")
with open(txt_dir, "w") as txt_file:
    for label, subfolder in enumerate(subfolders, start=0):
        subfolder_path = os.path.join(parent_folder, subfolder)
        image_files = [file for file in os.listdir(subfolder_path) if file.endswith(".jpg")]  # 假设图像文件扩展名为 jpg
        for image_file in image_files:
            file_path = os.path.join(subfolder_path, image_file)
            txt_file.write(f"{file_path} {label}\n")

print("File paths with labels have been written to 'file_paths_with_labels.txt'.")