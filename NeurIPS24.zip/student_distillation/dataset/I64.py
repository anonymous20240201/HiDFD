"""
get data loaders
"""
from __future__ import print_function

import _pickle
import os
import argparse

import torch
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
from collections import Counter
from PIL import Image
import random
import pickle
import numpy as np
def unpickle(file):
    import _pickle as cPickle
    with open(file, 'rb') as fo:
        dict = cPickle.load(fo, encoding='latin1')
    return dict


class I64_dataset(Dataset):
    def __init__(self, opt, transform, model='normal', pred=[]):

        self.transform = transform
        self.model = model
        self.train_data = []
        # self.train_target = []
        train_folder = opt.data_path
        for sub in os.listdir(train_folder):
            sub_dir = os.path.join(train_folder, sub)
            with open(sub_dir, 'rb') as fo:
                entry = _pickle.load(fo, encoding='latin1')
                self.train_data.append(entry['train']['data'])
                # self.train_target.append(entry['train']['target'])
        self.train_data = np.vstack(self.train_data).reshape(-1, 3, 64, 64)
        # self.train_target = np.vstack(self.train_target).reshape(-1, 1)
        self.train_data = self.train_data.transpose((0, 2, 3, 1))  # convert to HWC
        if self.model == 'select':
            self.train_data = self.train_data[pred]
            # self.train_target = self.train_target[pred]


    def __getitem__(self, index):
        # img, target = self.train_data[index], self.train_target[index]
        img = self.train_data[index]
        img = Image.fromarray(img)
        img = self.transform(img)
        # return img, target, index
        return img, index

    def __len__(self):
        return len(self.train_data)


def get_64_dataloader(opt):
    normalize = transforms.Normalize(mean=[0.4914, 0.4822, 0.4465],
                                     std=[0.2023, 0.1994, 0.2010])

    train_transform = transforms.Compose([
        transforms.RandomResizedCrop(64),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        normalize,
    ])
    npy_data = I64_dataset(opt, train_transform)
    print(len(npy_data))
    trainloader = DataLoader(
        dataset=npy_data,
        batch_size=opt.batch_size,
        shuffle=False,
        num_workers=opt.num_workers)
    return trainloader

def train_loader_select(teacher, data_train_loader, opt):
    value = []
    index = 0
    celoss = torch.nn.CrossEntropyLoss(reduction='none').cuda()
    teacher.eval()
    # for i, (inputs, _, _) in enumerate(data_train_loader):
    for i, (inputs, _) in enumerate(data_train_loader):
        inputs = inputs.cuda()
        outputs = teacher(inputs)
        pred = outputs.data.max(1)[1]
        loss = celoss(outputs, pred)
        value.append(loss.detach().clone())
        index += inputs.shape[0]

    values = torch.cat(value, dim=0)

    positive_index = values.topk(opt.num_select, largest=False)[1]

    positive_index = positive_index.tolist()
    normalize = transforms.Normalize(mean=[0.4914, 0.4822, 0.4465],
                                     std=[0.2023, 0.1994, 0.2010])
    train_transform = transforms.Compose([
        transforms.RandomResizedCrop(64),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        normalize,
    ])

    train_set = I64_dataset(opt, train_transform, model='select', pred=positive_index)
    print(len(train_set))
    trainloader_select = torch.utils.data.DataLoader(train_set, batch_size=opt.batch_size, shuffle=True,
                                                     num_workers=opt.num_workers)

    return trainloader_select